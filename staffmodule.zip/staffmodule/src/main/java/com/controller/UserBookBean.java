package com.controller;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.entity.BookEntity;

import com.model.UserBookRemote;

@ManagedBean(name="book",eager=true)
@SessionScoped
public class UserBookBean {
	
	private String title;
	private String author;
	private String isbn;
	private int days;
	
	@EJB(lookup="java:global/staffmodule/UserBookService!com.model.UserBookRemote")
	UserBookRemote ubr;
	
	private List<BookEntity> book;
	
	  public BookEntity addbooking()
	  {
		  BookEntity book = new BookEntity();
		    book.setTitle(title);
		    book.setAuthor(author);
		    book.setIsbn(isbn);
		    //book.setPublisher(publisher);
		    
		    
		    book = ubr.bookingdetails(book);
		    
		    return book;
	  }
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	


	public List<BookEntity> getBook() {
		return book;
	}


	public void setBook(List<BookEntity> book) {
		this.book = book;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	

	
	
	
}