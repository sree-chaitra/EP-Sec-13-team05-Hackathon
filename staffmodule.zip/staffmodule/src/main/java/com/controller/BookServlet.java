package com.controller;

import java.io.IOException;
//import java.util.List;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.BookEntity;
import com.model.UserBookService;
import com.model.UserService;

@WebServlet("/book")
public class BookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	// Get the form parameters
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String isbn = request.getParameter("isbn");
        
        // Assuming you have a way to get the username, e.g., from the session
        String username = (String) request.getSession().getAttribute("username");

        // Create a new book entity
        BookEntity book = new BookEntity();
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);

        // Call the userbookinsert method
        UserService userService = new UserService();
        userService.userbookinsert(username, book);

        // Redirect or forward to a success page
        response.sendRedirect("bookingdetails.jsp");
    }
    }