package com.controller;

import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.bean.ManagedBean;
import javax.faces.view.ViewScoped;
import java.io.Serializable;
import java.util.List;

import com.entity.BookEntity;
import com.model.BookRemote;

@ManagedBean(name="b",eager=true)
@ViewScoped
public class BookBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @EJB(lookup="java:global/staffmodule/BookService!com.model.BookRemote")
    BookRemote br;
    private String isbn;
    private String title;
    private String author;
    private String ack;
    private List<BookEntity> emplist;
    
  

    // Getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getAck() {
        return ack;
    }

    public void setAck(String ack) {
        this.ack = ack;
    }




public void callInsert() {
    try {
        BookEntity book = new BookEntity();
        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn);

        ack = br.insertBook(book);
    } catch (Exception e) {
        ack = e.getMessage();
    }
}

public String update()
{
	BookEntity emp =br.viewempbyisbn(isbn);

	
	if(emp!=null)
	{
			BookEntity b = new 	BookEntity();
		     b.setIsbn(isbn);
			 b.setTitle(title);
			b.setAuthor(author);
			
			br.updateemployee(b);
			
			return "BOOK UPDATED";
			
	}
	else
	{
		//System.out.println("id not found");
		return "UPDATE FAILURE";
	}
}
}

