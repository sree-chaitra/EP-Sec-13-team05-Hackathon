package com.controller;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.StaffEntity;
import com.entity.UserEntity;
import com.model.UserRemote;

@ManagedBean(name="u", eager=true)
public class UserBean {

    private String username;
    private String email;
    private String password;
    private String ack;
    private String role; // Added role attribute
    private UserEntity u;
    private String title;

    @EJB(lookup="java:global/staffmodule/UserService!com.model.UserRemote")
    private UserRemote ur;

    public void callinsert() {
        try { 
            UserEntity E = new UserEntity();
            E.setUsername(username);
            E.setEmail(email);
            E.setPassword(password);
            
            StaffEntity S = new StaffEntity();
            S.setUsername(username);
            S.setEmail(email);
            S.setPassword(password);

            if ("user".equals(role)) {
                ack = ur.insertuser(E);
            } else if ("staff".equals(role)) {
                ack = ur.insertuser(S);
            } else {
                ack = "Invalid role selected";
            }
        } catch(Exception e) {
            ack = "Error: " + e.getMessage();
        }
    }

    public void validatelogin() throws Exception {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ExternalContext externalContext = facesContext.getExternalContext();
        HttpServletRequest request = (HttpServletRequest) externalContext.getRequest();
        HttpServletResponse response = (HttpServletResponse) externalContext.getResponse();

        if (ur != null) {
            UserEntity e = ur.loginuser(username, password);
            if (e != null) {
                System.out.println("Login Success");
                HttpSession session = request.getSession();
                session.setAttribute("emp", e);
                session.setAttribute("username", e.getUsername());
                ur.userbook(e.getUsername());
                response.sendRedirect("uhome.jsp"); // Ensure this path is correct
            } else {
                System.out.println("Login Failed");
                response.sendRedirect("signupuser.jsf");
            }
        } else {
            throw new Exception("UserRemote EJB not available.");
        }
    }

    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getAck() { return ack; }
    public void setAck(String ack) { this.ack = ack; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public UserEntity getU() { return u; }
    public void setU(UserEntity u) { this.u = u; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
}
