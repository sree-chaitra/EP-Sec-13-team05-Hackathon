package com.controller;

import com.model.AdminService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteStaff")
public class DeleteStaffServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");

        AdminService as = new AdminService();
        as.deleteEmp(username);

        // Redirect back to the viewall.jsp page with the deleted username as a query parameter
        response.sendRedirect("adminviewall.jsp?deletedUsername=" + username);
    }
}