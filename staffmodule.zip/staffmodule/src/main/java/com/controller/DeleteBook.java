package com.controller;


import com.model.BookService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deletebook")
public class DeleteBook extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");

        BookService as = new BookService();
        as.deletebook(title);

        // Redirect back to the viewallbooks.jsp page with the deleted title as a query parameter
        response.sendRedirect("viewall.jsp?deletedtitle=" + title);
    }
}
