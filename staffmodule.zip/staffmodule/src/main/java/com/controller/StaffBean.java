package com.controller;

import java.io.IOException;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.StaffEntity;
import com.model.StaffRemote;


@ManagedBean(name="s",eager =true)
public class StaffBean {
	
	
	private String username;
	private String email;
	private String password;
	private String ack;
	private String role; 
	
	@EJB(lookup="java:global/staffmodule/StaffService!com.model.StaffRemote")
	StaffRemote ur;
	
	
	public void callinsert() {
		
		try { 
			StaffEntity E = new StaffEntity();
			E.setUsername(username);
			E.setEmail(email);
			E.setPassword(password);
			
		    ack=ur.insertuser(E);
			
		}
		catch(Exception e) {
			ack = e.getMessage();
		}
	}
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getAck() {
		return ack;
	}

	public void setAck(String ack) {
		this.ack = ack;
	}

public void validatelogin() throws IOException
{
	
	FacesContext facescontext = FacesContext.getCurrentInstance();
	ExternalContext externalcontext = facescontext.getExternalContext();
	HttpServletRequest request = (HttpServletRequest) externalcontext.getRequest();
	HttpServletResponse response = (HttpServletResponse) externalcontext.getResponse();
	 StaffEntity  e = ur.checklogin(email, password);
	if(e!=null)
	{
		System.out.println("Login Success");
		//return "emphome.jsf";
		
		//explict object
		
		HttpSession session = request.getSession();
		session.setAttribute("emp", e);
		
		response.sendRedirect("StaffHome.jsf");
		
	}
	else
	{
		System.out.println("Login Failed");
		//return "loginfail.jsf";
		response.sendRedirect("signupuser.jsf");
		
	}
}
public void avalidateLogin() throws IOException {
    FacesContext facesContext = FacesContext.getCurrentInstance();
    HttpServletRequest request = (HttpServletRequest) facesContext.getExternalContext().getRequest();
    HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();

    try {
        // Hardcoded admin password
        String adminPassword = "klu123";

        if (adminPassword.equals(password)) {
            System.out.println("Login Success");

            // Explicit session object
            HttpSession session = request.getSession();
            session.setAttribute("admin", true);

            response.sendRedirect("adminhome.jsf");
        } else {
            System.out.println("Login Failed");
         facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login Fail, Enter the correct passkey", "The password you entered is incorrect."));
facesContext.getExternalContext().getFlash().setKeepMessages(true);
            facesContext.getExternalContext().redirect("adminlogin.jsf");
        }
    } catch (Exception e) {
      
        System.out.println("An error occurred during login: " + e.getMessage());

        facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login Fail, Enter the correct passkey", "An unexpected error occurred. Please try again."));

        facesContext.getExternalContext().getFlash().setKeepMessages(true);
        facesContext.getExternalContext().redirect("adminlogin.jsf");
    }
}
}
