package com.model;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.entity.StaffEntity;


@Stateless
@TransactionManagement(value=TransactionManagementType.BEAN)
public class StaffService implements StaffRemote{

	@Override
	public String insertuser(StaffEntity E) throws Exception {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(E);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		return "inserted";
	}
	public StaffEntity checklogin(String email, String password) {
	    EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	    EntityManager em = emf.createEntityManager();
	    
	    try {
	        Query qry = em.createQuery("select e from StaffEntity e where e.email = :email and e.password = :password");
	        qry.setParameter("email", email);
	        qry.setParameter("password", password);
	        
	        StaffEntity emp = null;
	        List<StaffEntity> results = qry.getResultList();
	        if (!results.isEmpty()) {
	            emp = results.get(0);
	        }
	        return emp;
	    } finally {
	        em.close();
	        emf.close();
	    }
	}


}
