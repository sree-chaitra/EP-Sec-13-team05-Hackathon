package com.model;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.entity.BookEntity;
import com.entity.StaffEntity;



	
	@Stateless
	public class AdminService implements AdminRemote {

	    @Override
	    public List<StaffEntity> viewallemps() {
	        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	        EntityManager em = emf.createEntityManager();
	        
	        Query qry = em.createQuery("SELECT s FROM StaffEntity s");
	        
	        @SuppressWarnings("unchecked")
	        List<StaffEntity> emplist = qry.getResultList();
	        
	        em.close();
	        emf.close();
	        
	        return emplist;
	    }
	    public List<BookEntity> viewallbooks() {
	        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	        EntityManager em = emf.createEntityManager();
	        
	        Query qry = em.createQuery("SELECT s FROM BookEntity s");
	        
	        @SuppressWarnings("unchecked")
	        List<BookEntity> emplist = qry.getResultList();
	        
	        em.close();
	        emf.close();
	        
	        return emplist;
	    }

	    public void deleteEmp(String username) {
	        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	        EntityManager em = emf.createEntityManager();
	        
	        em.getTransaction().begin();
	        
	        Query qry = em.createQuery("DELETE FROM StaffEntity s WHERE s.username = :username");
	        qry.setParameter("username", username);
	        qry.executeUpdate();
	        
	        em.getTransaction().commit();
	        
	        em.close();
	        emf.close();
	    }
	    public void deletebook(String title) {
	        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

	    	 EntityManager em = emf.createEntityManager();
	         em.getTransaction().begin();
	         TypedQuery<BookEntity> query = em.createQuery("SELECT b FROM BookEntity b WHERE b.title = :title", BookEntity.class);
	         query.setParameter("title", title);
	         List<BookEntity> books = query.getResultList();
	         for (BookEntity book : books) {
	             em.remove(book);
	         }
	         em.getTransaction().commit();
	     }
	}


