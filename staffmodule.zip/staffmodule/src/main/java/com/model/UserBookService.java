package com.model;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.entity.BookEntity;

@Stateless
public class UserBookService implements UserBookRemote {

	@Override
	  public BookEntity searchbook(String title) {
	      EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	      EntityManager em = emf.createEntityManager();
	      
	      BookEntity b = em.find(BookEntity.class,title);
	      
	      return b;
	     
	  }

	@SuppressWarnings("unchecked")
	@Override
	public List<BookEntity> viewallemps() {
EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
      
      // Create an EntityManager from the factory
      EntityManager em = emf.createEntityManager();
      
      try {
          // Create a JPQL query to select all books from the database
          Query qry = em.createQuery("SELECT e FROM BookEntity e");
          
          // Execute the query and get the list of book entities
          List<BookEntity> bookList = qry.getResultList();
          
          return bookList;
      } finally {
          // Ensure resources are closed to prevent memory leaks
          em.close();
          emf.close();
      }
  }

	@Override
	public BookEntity bookingdetails(BookEntity book) {
		 
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
      EntityManager em = emf.createEntityManager();
      
      try {
          // Assuming book ID is the unique identifier
          Query qry = em.createQuery("SELECT e FROM BookEntity e WHERE e.title = :title");
          qry.setParameter("title", book.getTitle());

          // Retrieve the single book entity using the unique identifier
          BookEntity foundBook = (BookEntity) qry.getSingleResult();
          return foundBook;
         
      } catch (Exception e) {
          e.printStackTrace();
          return null; // Return null if no book is found or an error occurs
      } finally {
          em.close();
          emf.close();
      }
		
  }

	@Override
	public void userbook(String username,BookEntity book) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
      EntityManager em = emf.createEntityManager();
      
      try {
          em.getTransaction().begin();
          String sql = "CREATE TABLE IF NOT EXISTS " + username + " (" +
                       "id INT AUTO_INCREMENT PRIMARY KEY, " +
                       "title VARCHAR(255), " +
                       "author VARCHAR(255), " +
                       "isbn VARCHAR(255), " +
                       "date DATE)";
          Query query = em.createNativeQuery(sql);
          query.executeUpdate();
          em.getTransaction().commit();
      } catch (Exception e) {
          e.printStackTrace();
          em.getTransaction().rollback();
      } finally {
          em.close();
          emf.close();
      }
  }
	
}
