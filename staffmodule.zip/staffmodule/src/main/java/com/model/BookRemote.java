package com.model;

import java.util.List;

import javax.ejb.Remote;
import com.entity.BookEntity;

@Remote
public interface BookRemote {
    public String insertBook(BookEntity book) throws Exception;
    public String updateemployee(BookEntity employee);
	public BookEntity viewempbyisbn(String isbn);
	public List<BookEntity> viewallbooks();
	
	
    


 
}
