package com.model;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.entity.BookEntity;


@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class BookService implements BookRemote {

    @Override
    public String insertBook(BookEntity book) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(book);
        em.getTransaction().commit();

        em.close();
        emf.close();
        return "Book inserted";
    }



public String updateemployee(BookEntity employee) 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	EntityManager em = emf.createEntityManager();
	
	em.getTransaction().begin();
	
	BookEntity e = em.find(BookEntity.class, employee.getIsbn());
	e.setTitle(employee.getTitle());
	e.setAuthor(employee.getAuthor());

	
	em.getTransaction().commit();
	em.close();
	emf.close();
	
	return "Book. Updated Successfully";
}

public BookEntity viewempbyisbn(String eid) 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	EntityManager em = emf.createEntityManager();
	
	BookEntity e = em.find(BookEntity.class, eid);
	
	if(e==null)
	{
		em.close();
		emf.close();	
		
		return null;
	}
	em.close();
	emf.close();
	return e;
}
public List<BookEntity> viewallbooks() {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
    EntityManager em = emf.createEntityManager();
    
    javax.persistence.Query qry = em.createQuery("SELECT e FROM BookEntity e");

    
    @SuppressWarnings("unchecked")
    List<BookEntity> emplist = qry.getResultList();
    
    em.close();
    emf.close();
    
    return emplist;
}
public void deletebook(String title) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");

	 EntityManager em = emf.createEntityManager();
     em.getTransaction().begin();
     TypedQuery<BookEntity> query = em.createQuery("SELECT b FROM BookEntity b WHERE b.title = :title", BookEntity.class);
     query.setParameter("title", title);
     List<BookEntity> books = query.getResultList();
     for (BookEntity book : books) {
         em.remove(book);
     }
     em.getTransaction().commit();
 }
}