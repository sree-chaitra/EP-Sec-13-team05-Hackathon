package com.model;

import java.util.List;

import javax.ejb.Remote;

import com.entity.BookEntity;
import com.entity.StaffEntity;

@Remote
public interface AdminRemote {
	public List<StaffEntity> viewallemps();
	public List<BookEntity> viewallbooks();
}