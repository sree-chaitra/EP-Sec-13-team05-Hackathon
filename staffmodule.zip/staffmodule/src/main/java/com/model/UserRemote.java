package com.model;



import java.util.List;

import javax.ejb.Remote;

import com.entity.BookEntity;
import com.entity.StaffEntity;
import com.entity.UserEntity;

@Remote
public interface UserRemote {
	public String insertuser(UserEntity E)throws Exception;
	public UserEntity loginuser(String username, String password) throws Exception;
	 public void userbook(String username);
	 public boolean userbookinsert(String username,BookEntity B);
	 public List<BookEntity> getUserBookings(String username);
	 public String insertuser(StaffEntity E)throws Exception;
	 
}