package com.model;



import java.util.List;

import javax.ejb.Remote;

import com.entity.BookEntity;



@Remote
public interface UserBookRemote
{
  
  public BookEntity searchbook(String title);
  public List<BookEntity> viewallemps();
  public BookEntity bookingdetails(BookEntity book);
  public void userbook(String username,BookEntity book);
}