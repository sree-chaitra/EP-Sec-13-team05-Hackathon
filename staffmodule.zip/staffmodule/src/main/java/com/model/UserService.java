package com.model;



import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.entity.BookEntity;
import com.entity.StaffEntity;
import com.entity.UserEntity;

@Stateless
@TransactionManagement(value=TransactionManagementType.BEAN)
public class UserService implements UserRemote{



	@Override
	public String insertuser(UserEntity E) throws Exception {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(E);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		return "inserted";
		
		
	}

	

	@Override
	public UserEntity loginuser(String username, String password) throws Exception {
		
		    EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		    EntityManager em = emf.createEntityManager();
		    
		    try {
		        Query qry = em.createQuery("select e from UserEntity e where e.username = :username and e.password = :password");
		        qry.setParameter("username", username);
		        qry.setParameter("password", password);
		        
		        UserEntity emp = null;
		        List<UserEntity> results = qry.getResultList();
		        if (!results.isEmpty()) {
		            emp = results.get(0);
		        }
		        return emp;
		    } finally {
		        em.close();
		        emf.close();
		    }
		    
		    
		
	}
	@Override
	public void userbook(String username) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();
        
        try {
            em.getTransaction().begin();
            String sql = "CREATE TABLE IF NOT EXISTS " + username + " (" +
            		"id INT AUTO_INCREMENT PRIMARY KEY, " +
                         "title VARCHAR(255) UNIQUE, " +
                         "author VARCHAR(255), " +
                         "isbn VARCHAR(255), " +
                         "publisher VARCHAR(255), " +
                         "date DATE)";
            Query query = em.createNativeQuery(sql);
            query.executeUpdate();
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
            emf.close();
        }
    }



	@Override
	public boolean userbookinsert(String username,BookEntity book) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	    EntityManager em = emf.createEntityManager();

	    try {
	        em.getTransaction().begin();
	        String sql = "INSERT INTO " + username + " (title, author, isbn, publisher, date) VALUES (?, ?, ?, ?, ?)";
	        Query query = em.createNativeQuery(sql);
	        query.setParameter(1, book.getTitle());
	        query.setParameter(2, book.getAuthor());
	        query.setParameter(3, book.getIsbn());
	        query.setParameter(5, new Date());
	        query.executeUpdate();
	        em.getTransaction().commit();
	        return true;
	    } catch (Exception e) {
	        e.printStackTrace();
	        em.getTransaction().rollback();
	        return false;
	    } finally {
	        em.close();
	        emf.close();
	    }
		
		
    }



	
	@Override
	@SuppressWarnings("unchecked")
    public List<BookEntity> getUserBookings(String username) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
        EntityManager em = emf.createEntityManager();
        List<BookEntity> bookedBooks = null;

        try {
            em.getTransaction().begin();
            String sql = "SELECT title, author, isbn, publisher, date FROM " + username;
            Query query = em.createNativeQuery(sql, BookEntity.class);
            bookedBooks = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
        } finally {
            em.close();
            emf.close();
        }
        return bookedBooks;
    }



	@Override
	public String insertuser(StaffEntity E) throws Exception {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		em.persist(E);
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		return "inserted";
	}



	

	
	
		
	}