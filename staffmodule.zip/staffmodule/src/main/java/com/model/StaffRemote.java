package com.model;

import javax.ejb.Remote;

import com.entity.StaffEntity;

@Remote
public interface StaffRemote {
	
	public String insertuser(StaffEntity E)throws Exception;
	public StaffEntity checklogin(String email, String password);

}
